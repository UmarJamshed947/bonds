package com.example.bonds

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
